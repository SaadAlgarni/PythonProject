from PyQt5.QtChart import QChart, QChartView, QLineSeries, QBarSeries, QBarSet, QBarCategoryAxis, QValueAxis, QPieSeries, QPieSlice
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPainter, QPen


def create_line_chart(x_values, y_values, title):
    """
    Create a line chart widget
    :param x_values: Values for the X axis
    :param y_values: Values for the Y axis
    :param title: chart title
    :return:
    """
    series = QLineSeries()
    for x, y in zip(x_values, y_values):
        series.append(x, y)

    chart = QChart()

    chart.addSeries(series)
    chart.createDefaultAxes()
    chart.setAnimationOptions(QChart.SeriesAnimations)
    chart.setTitle(title)

    chart.legend().setVisible(True)
    chart.legend().setAlignment(Qt.AlignBottom)

    chartview = QChartView(chart)
    chartview.setRenderHint(QPainter.Antialiasing)
    return chartview


def create_bar_chart(x_values, y_values, title):
    """
    Create a bar chart widget
    :param x_values: Values for the X axis
    :param y_values: Values for the Y axis
    :param title: chart title
    :return:
    """
    set0 = QBarSet('X')
    set0.append(x_values)

    series = QBarSeries()
    series.append(set0)

    chart = QChart()
    chart.addSeries(series)
    chart.setTitle(title)

    chart.setAnimationOptions(QChart.SeriesAnimations)

    axisY = QValueAxis()
    chart.addAxis(axisY, Qt.AlignLeft)
    series.attachAxis(axisY)


    axisX = QBarCategoryAxis()
    axisX.append(y_values)
    chart.addAxis(axisX, Qt.AlignBottom)
    series.attachAxis(axisX)

    axisY.applyNiceNumbers()

    chart.legend().setVisible(True)
    chart.legend().setAlignment(Qt.AlignBottom)

    chartView = QChartView(chart)
    chartView.setRenderHint(QPainter.Antialiasing)
    return chartView


def create_pie_chart(values, labels, title):
    """
    Create a pie chart widget
    :param values: Values for the slices
    :param labels: Values for the labels
    :param title: chart title
    :return:
    """
    series = QPieSeries()
    for value, label in zip(values, labels):
        series.append(label, value)

    chart = QChart()
    chart.legend().hide()
    chart.addSeries(series)
    chart.createDefaultAxes()
    chart.setAnimationOptions(QChart.SeriesAnimations)
    chart.setTitle(title)

    chart.legend().setVisible(True)
    chart.legend().setAlignment(Qt.AlignBottom)

    chartview = QChartView(chart)
    chartview.setRenderHint(QPainter.Antialiasing)
    return chartview
