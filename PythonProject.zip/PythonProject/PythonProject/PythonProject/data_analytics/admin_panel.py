from PyQt5 import QtCore, QtGui, QtWidgets, uic
import sys
from PyQt5.QtWidgets import QTableWidgetItem
import resources_rc
import backend as bk
import datetime


qtcreator_file = "admin_view.ui"  # Enter file here.
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)


class ADMP(QtWidgets.QMainWindow, Ui_MainWindow):

    def __init__(self):
        """
        constructor

        """
        QtWidgets.QMainWindow.__init__(self)  # inheritance of QMainWindow
        Ui_MainWindow.__init__(self)  # inheritance of Ui_MainWindow

        self.setupUi(self)
        exitAct = QtWidgets.QAction('Exit', self)
        exitAct.setShortcut('Ctrl+Q')
        exitAct.setStatusTip('Exit application')
        exitAct.triggered.connect(QtWidgets.qApp.quit)

        menubar = self.menuBar()
        optMenu = menubar.addMenu('Options')
        optMenu.addAction(exitAct)

        self.query = ""
        self.query_name = ""
        self.chart_dict = {}

        self.add_bar_btn.clicked.connect(self.set_bar_options)
        self.add_line_btn.clicked.connect(self.set_line_options)
        self.add_pie_btn.clicked.connect(self.set_pie_options)

        self.preview_data_btn.clicked.connect(self.preview_data)
        self.save_query_btn.clicked.connect(self.save_query)

    def save_query(self):
        self.query_name = self.query_name_edit.text()

        if not self.query:
            self.set_error("The query cannot be empty")
            return
        if not self.query_name:
            self.set_error("The query name cannot be empty")
            return
        if not self.chart_dict:
            self.set_error("The chart json cannot be empty")
            return
        chart_string = " ".join([f"{key},{self.chart_dict[key]['x']},{self.chart_dict[key]['y']}" for key in self.chart_dict.keys()])
        bk.create_new_query(self.query, chart_string, self.query_name)
        self.set_success(f"{self.query_name} successfully created!")

    def clear_error(self):
        """
        Clears the error label
        """
        self.error_label.clear()

    def set_error(self, value):
        """
        Sets the error label
        :param value:  Error to set in the label
        :return:
        """
        self.error_label.clear()
        self.error_label.setText(value)

    def preview_data(self):
        self.query = self.query_edit.toPlainText()
        print(self.query)
        if not self.query:
            self.set_error("The query field cannot be empty!")
            return
        data, headers = bk.fetch_query(self.query)
        self.set_combo_options(headers)
        self.add_items(data)
        self.set_headers(headers)
        self.clear_error()

    def set_combo_options(self, options):
        """
        Adds the columns to the combo boxes
        :param options:
        :return:
        """
        combo_boxes = [self.bar_x,
                       self.bar_y,
                       self.line_x,
                       self.line_y,
                       self.pie_x,
                       self.pie_y
                       ]
        [cbx.clear() for cbx in combo_boxes]
        [cbx.addItems(options) for cbx in combo_boxes]

    def set_bar_options(self):
        self.chart_dict["bar"] = {"x": self.bar_x.currentText(),
                                  "y": self.bar_y.currentText()}
        self.set_chart_json()

    def set_line_options(self):
        self.chart_dict["line"] = {"x": self.line_x.currentText(),
                                   "y": self.line_y.currentText()}
        self.set_chart_json()

    def set_pie_options(self):
        self.chart_dict["pie"] = {"x": self.pie_x.currentText(),
                                  "y": self.pie_y.currentText()}
        self.set_chart_json()

    def set_success(self,value):
        """

        :param value:
        :return:
        """
        self.success_label.clear()
        self.success_label.setText(value)

    def set_chart_json(self):
        """
        set the chart json
        :return:
        """
        self.chart_preview_edit.setPlainText(str(self.chart_dict))

    def add_items(self, items):
        """
        add the items to the table
        :param items: list of user string items
        :return:
        """
        self.tableWidget.setRowCount(len(items))
        self.tableWidget.setColumnCount(len(items[0]))
        for row, row_item in enumerate(items):
            [self.tableWidget.setItem(row, col, QTableWidgetItem(str(item))) for col, item in enumerate(row_item)]

    def set_headers(self, headers_list):
        """
        sets the headers of the table
        :param headers_list:
        :return:
        """
        self.tableWidget.setHorizontalHeaderLabels(headers_list)

    def clear_table_widget(self):
        """
        Clear the table
        :return:
        """
        self.tableWidget.clear()

    def adjust_table_widget(self):
        """
        Adjust the table according to the content size
        :return:
        """
        header = self.tableWidget.horizontalHeader()
        header.setStretchLastSection(True)
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.tableWidget.resizeColumnsToContents()

