from PyQt5 import QtWidgets, uic
import sys
import backend as bk
import resources_rc
from admin_panel import ADMP
from user_panel import UMP

qtcreator_file = "login.ui"                                # Path for the UI file is provided here
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)  # Loads the UI file


class Main(QtWidgets.QDialog, Ui_MainWindow):

    def __init__(self):
        QtWidgets.QDialog.__init__(self)      # Inheritance of QDialog
        Ui_MainWindow.__init__(self)          # Inheritance Ui_MainWindow

        self.setupUi(self)                    # Enables the sub-components to be part of Main class
        self.dlg = ADMP()                      # The Admin Object is initiated
        self.ulms = None                      # User LMS end
        self.LoginButton.clicked.connect(self.authenticate)  # Perform the authenticate function on login button click

    def set_error(self, value):
        """
        Sets the error label
        :param value:  Error to set in the label
        :return:
        """
        self.error_label.clear()
        self.error_label.setText(value)

    def authenticate(self):
        """
        This function handles the main login based on user provided values
        :return:
        """
        username = self.username_edit.text()  # get the username from the UI
        password = self.password_edit.text()  # get the password from the UI
        authenticated = bk.authenticate(username, password)  # apply the authenticate method in backend.py

        if authenticated:    # When the user authenticates successfully
            if authenticated[1] == 'admin':  # if the user is the admin

                self.error_label.clear()  # Clears the error
                self.dlg.show()  # Display the ADM dialog
                self.hide()      # Hide the Login Dialog
            else:  # if the user is the client
                self.ulms = UMP()  # the User object is initialized
                self.ulms.show()  # Shows the user LMS dialog
                self.hide()  # Hide the Login Dialog
        else:
            self.set_error("Incorrect Credentials!")  # Message to show when the credentials are incorrect


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')

    window = Main()
    window.show()
    sys.exit(app.exec_())