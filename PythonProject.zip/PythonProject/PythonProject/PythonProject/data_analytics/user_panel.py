from PyQt5 import QtCore, QtGui, QtWidgets, uic
import sys
from PyQt5.QtWidgets import QTableWidgetItem
import resources_rc
import backend as bk
from charts import *

qtcreator_file = "user_view.ui"  # Enter file here.
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)


class UMP(QtWidgets.QMainWindow, Ui_MainWindow):

    def __init__(self):
        """
        constructor
        :param user_id: user id when the user is not the admin
        """
        QtWidgets.QMainWindow.__init__(self)  # inheritance of QMainWindow
        Ui_MainWindow.__init__(self)  # inheritance of Ui_MainWindow

        self.setupUi(self)
        exitAct = QtWidgets.QAction('Exit', self)
        exitAct.setShortcut('Ctrl+Q')
        exitAct.setStatusTip('Exit application')
        exitAct.triggered.connect(QtWidgets.qApp.quit)

        menubar = self.menuBar()
        optMenu = menubar.addMenu('Options')
        optMenu.addAction(exitAct)

        self.queries_dict = None

        self.set_selectable_queries()
        self.query_combo.currentIndexChanged[str].connect(self.worker)

    def set_selectable_queries(self):
        """

        :return:
        """
        self.queries_dict = bk.get_query_names()

        self.query_combo.clear()
        self.query_combo.addItems([""]+[query for query in self.queries_dict.keys()])

    def worker(self, query_key):
        """

        :param query_key:
        :return:
        """
        try:
            selected_query = self.queries_dict[query_key]
            query = selected_query["query"]
            charts_json = selected_query["charts"]
            data = bk.fetch_query(query)
            self.create_charts(charts_json, data)
            rows, headers = data
            self.clear_table_widget()
            self.set_headers(headers)
            self.add_items(rows)
            self.adjust_table_widget()
        except KeyError:
            return

    def create_charts(self, chart_json, data):
        """

        :param chart_json:
        :param data:
        :return:
        """
        charts_string = chart_json.split(' ')
        chart = {plt.split(',')[0]: {"x": plt.split(',')[1], "y": plt.split(',')[2]} for plt in charts_string}
        if "bar" in chart.keys():
            x_index = data[1].index(chart["bar"]["x"])
            y_index = data[1].index(chart["bar"]["y"])
            x_values = [val[x_index] for val in data[0]]
            y_values = [val[y_index] for val in data[0]]
            bar_chart = create_bar_chart(x_values, y_values, "BAR GRAPH")
            self.chart3.hide()
            self.gridLayout.addWidget(bar_chart, 6, 2)
        else:
            self.chart2.hide()
        if "pie" in chart.keys():
            x_index = data[1].index(chart["pie"]["x"])
            y_index = data[1].index(chart["pie"]["y"])
            x_values = [val[x_index] for val in data[0]]
            y_values = [val[y_index] for val in data[0]]
            pie_chart = create_pie_chart(x_values, y_values, "PIE GRAPH")

            # self.gridLayout.removeWidget(self.chart1)
            self.chart1.hide()
            self.gridLayout.addWidget(pie_chart, 6, 0)
            # pie_chart.setFixedWidth(300)
            # pie_chart.setFixedHeight(250)
        else:
            self.gridLayout.removeWidget(self.chart1)

        if "line" in chart.keys():
            x_index = data[1].index(chart["line"]["x"])
            y_index = data[1].index(chart["line"]["y"])
            x_values = [val[x_index] for val in data[0]]
            y_values = [val[y_index] for val in data[0]]
            line_chart = create_line_chart(x_values, y_values, "LINE GRAPH")
            self.chart2.hide()
            self.gridLayout.addWidget(line_chart, 6, 1)
        else:
            self.chart3.hide()

    def add_items(self, items):
        """
        add the items to the table
        :param items: list of user string items
        :return:
        """
        self.tableWidget.setRowCount(len(items))
        self.tableWidget.setColumnCount(len(items[0]))
        for row, row_item in enumerate(items):
            [self.tableWidget.setItem(row, col, QTableWidgetItem(str(item))) for col, item in enumerate(row_item)]

    def set_headers(self, headers_list):
        """
        sets the headers of the table
        :param headers_list:
        :return:
        """
        self.tableWidget.setHorizontalHeaderLabels(headers_list)

    def clear_table_widget(self):
        """
        Clear the table
        :return:
        """
        self.tableWidget.clear()

    def adjust_table_widget(self):
        """
        Adjust the table according to the content size
        :return:
        """
        header = self.tableWidget.horizontalHeader()
        header.setStretchLastSection(True)
        header.setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        self.tableWidget.resizeColumnsToContents()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')
    window = UMP()
    window.show()
    sys.exit(app.exec_())