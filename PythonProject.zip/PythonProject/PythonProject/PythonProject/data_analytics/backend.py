import sqlite3


def connect():
    """
    Connect to the sqlite DB
    :return:
    """
    conn = sqlite3.connect("data.db")

    return conn


def fetch_query(query, params=None):
    """
    The Wrapper function to fetch all the items for a query
    :param query: SQL query
    :param params: tuple of objects
    :return:
    """
    conn = connect()
    cur = conn.cursor()
    if params:
        cur.execute(query, params)
    else:
        cur.execute(query)
    rows = cur.fetchall()
    columns = [description[0] for description in cur.description]

    conn.close()
    return rows, columns


def modify_query(query, params=None):
    """
    The Wrapper function to execute a query without return
    :param query: SQL query
    :param params: tuple of objects
    :return:
    """
    conn = connect()
    cur = conn.cursor()
    try:
        if params:
            cur.execute(query, params)
        else:
            cur.execute(query)
        status = True
        conn.commit()
        conn.close()
    except Exception as err:
        print(str(err))
        status = False
    return status


def authenticate(username: str, password: str):
    """
    This method checks if the user exists in the database
    :param username:
    :param password:
    :return:
    """
    status = fetch_query("SELECT id,role FROM users WHERE username=? AND password=?", (username, password))
    if status:
        return status[0][0]
    else:
        return False


def create_new_query(query, chart_json, name):
    """

    :param query: username for the client
    :param chart_json: password for the client
    :param name: password for the client
    :return:
    """
    try:
        modify_query("INSERT INTO queries (query,charts,name) VALUES(?,?,?)", (query, chart_json, name))
        return "Success"
    except Exception as err:
        return str(err)


def get_query_names():
    """

    :return:
    """
    queries = fetch_query("SELECT name,query,charts FROM queries")
    return {query[0]: {"query": query[1], "charts": query[2]} for query in queries[0]}


if __name__ == '__main__':
    print(fetch_query("SELECT country, province from cases LIMIT 100"))